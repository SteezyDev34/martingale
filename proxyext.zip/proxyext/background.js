const proxy = {
  host: "115.167.26.81",
  port: "51523",
  auth: {
    username: "auxobettingproxy",
    password: "Scorpion971"
  }
};

// Spécifiez le domaine cible pour le proxy
const targetDomain = "ultimatetennisstatistics.com;

chrome.webRequest.onAuthRequired.addListener(
  (details) => {
    // Applique l'authentification seulement si l'URL correspond au domaine cible
    if (details.challenger.host.includes(targetDomain)) {
      return {
        authCredentials: {
          username: proxy.auth.username,
          password: proxy.auth.password
        }
      };
    }
  },
  { urls: [`*://${targetDomain}/*`] },  // Limiter aux URLs du domaine cible
  ["blocking"]
);
