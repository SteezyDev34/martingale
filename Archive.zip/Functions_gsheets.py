import pygsheets

global gc
gc = pygsheets.authorize(service_file='../1xbot/auxobetting-7a3cf182ba61.json')
#SUIVIS LOST 40 A
def suivi_lost(values):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[6]
    row = wk1.get_all_values()
    rows = len(row)
    if rows ==1 and wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)==['', '', '','']:
        wk1.update_row(rows,values, col_offset=0)
    else:
        wk1.insert_rows(0, number=1, values=values, inherit=False)
# SUIVIS LOST 30 A
def suivi_lost30(values):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[7]
    row = wk1.get_all_values()
    rows = len(row)
    if rows ==1 and wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)==['', '', '','']:
        wk1.update_row(rows,values, col_offset=0)
    else:
        wk1.insert_rows(0, number=1, values=values, inherit=False)
#MISE A JOUR DES PERTE GENERAL
def update_lost(row, values):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[1]
    # Updates values in a row from 1st column
    wk1.update_row(row + 4, [values], col_offset=1)
#RÉCUPRER LES PERTE 40 A DE LA LIGUE
def get_perte_en_cours(ligue_name):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[6]
    # Updates values in a row from 1st column
    row = wk1.get_all_values()
    rows = len(row)
    i=0
    print('get suiv '+ ligue_name)


    if rows ==1 and wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)==['', '', '','']:
        return False
    else:
        while rows != 0:
            data = wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)
            print('get suiv ' + ligue_name)
            if data[3] == ligue_name:
                data.append(rows)
                print("compet ok in")
                break
            else:
                rows = rows - 1
        return data
#RÉCUPRER LES PERTE 30 A DE LA LIGUE
def get_perte_en_cours30A(ligue_name):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[7]
    # Updates values in a row from 1st column
    row = wk1.get_all_values()
    rows = len(row)
    i=0
    print('get suiv '+ ligue_name)


    if rows ==1 and wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)==['', '', '','']:
        return False
    else:
        while rows != 0:
            data = wk1.get_row(rows, returnas='matrix', include_tailing_empty=True)
            print("dat find :"+data[3] )
            print('get suiv ' + ligue_name)
            data.append(rows)
            print("compet ok in : "+str(data))
            break
        return data
#SUPPRIMER LA PERTE RRÉCUPÉRÉE DU TABLEAU
def del_perte_en_cours(rows):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[6]
    # Updates values in a row from 1st column
    row = wk1.get_all_values()
    nbrows = len(row)
    if rows ==0:
        wk1.update_row(rows, ["","","",""], col_offset=0)
    elif nbrows == 1:
        wk1.update_row(rows, ["", "", "", ""], col_offset=0)
    else:
        wk1.delete_rows(rows, number=1)
#RÉCUPÉRER LES PERTES GÉNÉRALES
def get_perte_generale():
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[0]
    # Updates values in a row from 1st column
    print(wk1.get_value('B4'))
    try:
        float(wk1.get_value('B4').replace(",", "."))
    except:
        return 0
    else:
        return float(wk1.get_value('B4').replace(",", "."))
#MISEE A JOURR PERTE
def maj_perte(col, val, x):
    # open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)
    sh = gc.open('BOT 1XBET PYTHON')
    # select the sheet
    wk1 = sh[0]
    # Updates values in a row from 1st column
    if col == 1:
        z = "C" + str(x)
    elif col == 2:
        z = "D" + str(x)
    elif col == 3:
        z = "E" + str(x)
    elif col == 4:
        z = "F" + str(x)
    elif col == 5:
        z = "G" + str(x)
    elif col == 6:
        z = "H" + str(x)
    elif col == 7:
        z = "J" + str(x)
    elif col == 8:
        z = "I" + str(x)
    elif col == 9:
        z = "K" + str(x)
    wk1.update_value(z, val)
#INFOS DE MISE
def get_infos_de_mise(ligue_name,rattrape_perte,perte,wantwin,mise,increment):
    print("RECHERCHDES DES INFOS DE MISE...")
    infos = get_perte_en_cours(ligue_name)
    if infos != False:
        lost_compet = infos[3]
        if ligue_name == lost_compet:
            perte = float(infos[0].replace(",", "."))
            wantwin = float(infos[1].replace(",", "."))
            mise = float(infos[2].replace(",", "."))
            rattrape_perte = 1
            del_perte_en_cours(infos[4])
            print("perte : " + str(
                perte) + " | wantwin : " + str(
                wantwin) + " | mise : " + str(mise))
        elif rattrape_perte == 0:
            if int(get_perte_generale()) > 0.2:
                rattrape_perte = 1
                perte = 0
                mise = 0.2
                increment = 0.2
                wantwin = 0.2
        print("perte : " + str(
            perte) + " | wantwin : " + str(
            wantwin) + " | mise : " + str(mise))
    else:
        if rattrape_perte == 0:
            if int(get_perte_generale()) > 0.2:
                rattrape_perte = 1
        print("perte : " + str(
            perte) + " | wantwin : " + str(
            wantwin) + " | mise : " + str(mise))
    return [perte,wantwin,mise,increment,rattrape_perte]

def get_infos_de_mise30A(ligue_name,rattrape_perte,perte,wantwin,mise,increment):
    print("RECHERCHDES DES INFOS DE MISE...")
    infos = get_perte_en_cours30A(ligue_name)
    if infos != False:
        lost_compet = infos[3]
        perte = float(infos[0].replace(",", "."))
        wantwin = float(infos[1].replace(",", "."))
        mise = float(infos[2].replace(",", "."))
        rattrape_perte = 1
        del_perte_en_cours(infos[4])
        print("1 perte : " + str(
            perte) + " | wantwin : " + str(
            wantwin) + " | mise : " + str(mise))
    else:
        if rattrape_perte == 0:
            if int(get_perte_generale()) > 0.2:
                rattrape_perte = 1
        print("3 perte : " + str(
            perte) + " | wantwin : " + str(
            wantwin) + " | mise : " + str(mise))
    return [perte,wantwin,mise,increment,rattrape_perte]
