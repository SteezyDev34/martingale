global gc

import re
import random
import time
import Functions_gsheets
import Functions_1XBET

from selenium.webdriver.common.by import By

score_gamestart_list = [
    '40:15',
    '15:40',
    '0:30',
    '30:0',
    '30:30',
    '30:40',
    '40:30',
    '0:40',
    '40:0',
    '40:40',
    'A:40',
    '40:A',
    '0:0'
]
compet_not_ok_list = [
    'cyber',
    'world',
    'ace',
    'russie'
]
score_to_start = [
    "00(0)00(0)",
]

def all_script(driver, script_num, setaffiche, error, win, mise, perte, wantwin, increment, cote, lose, firstgame,
               jeu, set_actuel, set, score_actuel, passageset, x, match_list, match_done_key, match_found,
               rattrape_perte,matchlist_file_name,running_file_name):
    ##RECHERCHE DE MATCH
    Functions_1XBET.del_running(script_num,running_file_name)
    error = 0
    newmatch = "no-newmatch"
    compet_ok = "no-compet-ok"

    compet_ok_list = [
        'femmes',
        'féminin',
        'atp',
        'wta',
        'itf',
        'master',
        'challenger',
        'utr',
        'doubles',
        'couples',
        'laver'
    ]
    compet_not_ok_list = [
        'cyber',
        'world',
        'ace',
        'russie',
         'daily'
    ]
    # AUCUN MATCH TROUVE
    printtext = 0
    #SCRIPT RECHERCHE DE MATCH
    if Functions_1XBET.verification_page_de_match(driver) == True:
        print('PAGE MATCH OK!')
        ligue_name = Functions_1XBET.get_ligue_name_from_url(driver)
        newmatch = Functions_1XBET.verification_match_trouve_url(driver, matchlist_file_name)[1]
        match_found = 1
    print_running_text = 0
    while (match_found == 0 and error == 0):
        ifrunning = False
        if printtext == 0:
            print("wainting for go!")

        while ifrunning != True:
            ifrunning = Functions_1XBET.get_if_running(script_num,running_file_name)
            if ifrunning == True:
                print_running_text = 0
            else:
                if print_running_text == 0:
                    print("script " + str(script_num) + " STOP!")
                    print_running_text = 1

            script_running = 1
        if printtext == 0:
            print("script "+str(script_num)+" GO!")
        if printtext == 0:
            print('RECHERHCE DE MATCH')
        if Functions_1XBET.verification_liste_match_live(driver) == True:
            if printtext == 0:
                print('LISTE MATCH LIVE OK!')
                printtext = 1
            #RECUPERATION DES LIGUES EN COURS
            bet_list_ligue = driver.find_elements(By.XPATH,
                '//*[@id="games_content"]/div/div[1]/div/div')
            if len(bet_list_ligue) > 0:#SI DES LIGUES SONT RÉCUPÉRÉES
                for bet_ligue in bet_list_ligue:
                    if match_found != 0:
                        break  # si un match est trouvé on arrete la recherche
                    ligue_name = Functions_1XBET.get_ligue_name(bet_ligue)#ON RÉCUPÈRE LE NOM DE LA LIGUE
                    if ligue_name == False: #ON RÉCUPÈRE LE NOM DE LA LIGUE
                        error = 1
                        break
                    if any(compet_ok in ligue_name for compet_ok in
                           compet_ok_list) and not any(
                        compet_not_ok in ligue_name for
                        compet_not_ok in compet_not_ok_list):

                        #PARTIE A VERIFIER
                        for compet_ok in compet_ok_list:
                            if compet_ok in ligue_name:
                                break
                        #ON RÉCUPÈRE LES MATCHS DE LA LIGUE
                        try:
                            bet_items = bet_ligue.find_elements(By.CLASS_NAME,
                                    'c-events-scoreboard__item')
                        except:
                            continue

                        else:
                            if len(bet_items) > 0:#SI DES MATCHS SONT RÉCUPÉRÉS
                                #print('Vérification du score!')
                                for bet_item in bet_items:
                                    if match_found != 0:
                                        break # si un match est trouvé on arrete la recherche
                                    try:
                                        div_bet_score = bet_item.find_elements(By.CLASS_NAME,
                                            'c-events-scoreboard__lines_tennis')
                                    except:
                                        print("Impossible de récupérer le score")
                                    else:
                                        if len(div_bet_score) > 0:
                                            bet_score = Functions_1XBET.get_match_score(div_bet_score[0],score_to_start)
                                            if bet_score == True:#SI LE MATCH EST PRET
                                                #ON VERIFIE QU'IL N'A PAS DÉJA ÉTÉ PARIÉ
                                                newmatch =Functions_1XBET.verification_match_trouve(bet_item,matchlist_file_name)
                                                if newmatch[0] == True:
                                                    if Functions_1XBET.ouverture_page_match(bet_item, script_num, newmatch[1],running_file_name) == True:
                                                        match_found = 1
                                                        newmatch = newmatch[1]
                                                    else:
                                                        error = 1
        else:
            error=1
    #END SCRIPT RECHERCHE DE MATCH

    #RECHERCHE INFOS DE MISE
    print('enttr match')
    infos_de_mise = Functions_gsheets.get_infos_de_mise30A(ligue_name,rattrape_perte,perte,wantwin,mise,increment)
    perte=infos_de_mise[0]
    wantwin=infos_de_mise[1]
    mise=infos_de_mise[2]
    increment = infos_de_mise[3]
    saved_set = ""
    #END RECHERCHE INFOS DE MISE

    if error == 0:
        set_actuel = Functions_1XBET.get_set_actuel(driver, error,saved_set)
        saved_set = set_actuel
        if set_actuel == False:
            error=1
        try:
            numset = int(set_actuel.split(' ')[0])
        except:
            error = 1
        else:
            set = str(numset) + " Set"
            set_actuel = set
            # print("set actuel : " + set)
    ##PREPARATTION PREMIER PARIS
    bet_30a = 0
    while bet_30a == 0 and error == 0:
        print('iou')
        if Functions_1XBET.selection_des_paris_du_set(driver,set) == True:
            error = 0
            jeu = Functions_1XBET.recherche_paris_30a(driver, jeu)
            if jeu[0]!=0:
                jeu = jeu[1]
            else:
                error = 1
        else:
            Functions_1XBET.verification_page_de_match(driver)
            error = 1
            break
        print('retdf')
        send_mise = 0
        """infos_de_mise = get_mise(driver,rattrape_perte,wantwin,perte)
        mise = infos_de_mise[0]
        cote = infos_de_mise[1]"""
        while send_mise == 0 and error == 0:
            if Functions_1XBET.placer_mise(driver, mise) == True:
                send_mise = 1
            else:
                error=1
        validate_bet = 0
        gamestart = 0
        tentative = 0
        saved_score = ""
        ##VALIDATION DU PARIS SI SCORE OK
        while validate_bet == 0 and error == 0 and tentative <30:
            #VÉRIFICATION DU SCORE ACTUEL
            score_actuel = Functions_1XBET.get_score_actuel(driver,saved_score)
            saved_score = score_actuel
            if score_actuel == False:
                error = 1
                print("estr")
                ###ajouter ici les actions avant de reprendre
            elif score_actuel == "30:30":
                error = 1
                print("30A leave!")
                Functions_1XBET.delete_bet(driver, error)
                ###ajouter ici les actions avant de reprendre
                break
            else:
                print('gamestart')
                gamestart = 1
            if Functions_1XBET.first_validation_du_paris(driver,jeu,mise) == True:
                validate_bet = 1
                jeu = jeu + 1
                perte = perte + mise
                wantwin = wantwin + increment
                bet_30a = 1
                print("prochain jeu : " + str(jeu))
                print("wantwin : " + str(wantwin))
                print("perte : " + str(perte))
                print("mise : " + str(mise))
                print("increment : " + str(increment))
            else:
                getjeu = Functions_1XBET.get_jeu_actuel(driver)
                tentative = tentative + 1
                validate_bet = 2
                print('pari non validé')
                if getjeu != jeu:
                    print('testtvzdxz')
                    break

        #RETOUR SUR LA SECTION TPS REGLEMENTAIRE
    print("retour tps reg 1")
    Functions_1XBET.retour_section_tps_reglementaire(driver)
    ### AND PREPARE FIRST GAME
    winmatch = 0
    while (winmatch <= 0 and error == 0):
        # WAIT FOR GAME START
        if passageset == 1:
            score_actuel = '0:0'
            gamestart = 1
            if rattrape_perte == 1:
                error = 0
                print("passage set 2")
            else:
                error = 1
                print("erreur perte en 1 set")
        else:
            gamestart = 0
        ##ATTENTE QUE LE JEU COMMENCE
        Functions_1XBET.get_if_game_start_scnd(driver,saved_score)
        printext = 0
        # JEU COMMENCÉ ON PREPARE LE PROCHAIN BET
        bet_30a = 0
        while bet_30a == 0 and error == 0:

            if Functions_1XBET.selection_des_paris_du_set(driver, set) == True:
                error = 0
                jeu = Functions_1XBET.recherche_paris_30a(driver, jeu)
                if jeu[0] != 0:
                    jeu = jeu[1]+1
                    bet_30a = 1
                else:
                    error = 1
            else:
                Functions_1XBET.verification_page_de_match(driver)
                error = 1
                break
        #ON ENVOIE LA MISE
        send_mise = 0
        infos_de_mise = Functions_1XBET.get_mise(driver, rattrape_perte, wantwin, perte)
        mise = infos_de_mise[0]
        cote = infos_de_mise[1]
        while send_mise == 0 and error == 0:
            if Functions_1XBET.placer_mise(driver, mise) == True:
                send_mise = 1
            else:
                error = 1
        ##ON ATTEND LE RESULTAT POUR VALIDER LE PARIS
        validate_bet = 0
        saved_score = ""
        saved_set = ""
        timesleep = 1#TEMPS D'ATTENTE AVANT DE RECUPERER LE SCORE PASSE À 1 SI 30 DANS LE SCORE
        result = 0
        print("retour tps reg 2")
        Functions_1XBET.retour_section_tps_reglementaire(driver)
        while (result <= 0 and error == 0):
            time.sleep(timesleep)

            score_actuel = Functions_1XBET.get_score_actuel(driver,saved_score)
            saved_score = score_actuel
            if score_actuel == False:
                error = 1
            if score_actuel == '30:30':
                result = 1
                lose = 0
                winmatch = 1
                Functions_1XBET.delete_bet(driver, error)
                print('WIN')
            elif score_actuel == '40:0' or score_actuel == '40:15' or score_actuel == '0:40' or score_actuel == '15:40':
                print('LOSE')
                validate_bet = 0
                tentative = 0
                gamestart = 0
                lose = 1
                result = 1
                set_actuel = "nac"
                # print("vide sec actu " + set_actuel)
                set_actuel = Functions_1XBET.get_set_actuel(driver, error,saved_set)
                saved_set = set_actuel
                if set_actuel == False:
                    error = 1
                # print("recup set ectu" + set_actuel)
                numset = int(set.split(' ')[0])
                print('numset actuel ' + str(numset))
                newset = int(set.split(' ')[0]) + 1
                print('num prochain set ' + str(newset))
                # print('VERIFICATION DU SET PAR COPIE : ' + set_actuel)
                if len(re.findall(str(numset) + ' Set', set_actuel)) > 0:## si on est toujours sur le meme set

                    if jeu > 13:#SI TIE BREAK
                        print("attente fin de tie break")
                        passageset = 1
                    else:
                        ##VALIDATION DU PARIS SI SCORE OK
                        while validate_bet == 0 and error == 0:
                            # VÉRIFICATION DU SCORE ACTUEL
                            print('validation 987')
                            score_actuel = Functions_1XBET.get_score_actuel(driver,saved_score)
                            if score_actuel == False:
                                error = 1
                            if (score_actuel == "0:15" or score_actuel == "15:15" or score_actuel == "15:0" or score_actuel == "0:30" or score_actuel == "15:30" or score_actuel == "30:15" or score_actuel == "30:0") and gamestart == 1:
                                validate_bet = 0
                                #jeu = jeu + 1
                                print("GAME PASS WITHOUT VALIDATE")
                                gamestart = 1
                                result = 1
                                lose = 1
                                findbtn = 1

                                ###ajouter ici les actions avant de reprendre
                            elif score_actuel == "30:30":
                                error = 1
                                print("30A leave!")
                                Functions_1XBET.delete_bet(driver, error)
                                ###ajouter ici les actions avant de reprendre
                                break
                            else:
                                gamestart = 0
                                jeu = Functions_1XBET.get_jeu_actuel(driver)
                                if Functions_1XBET.validation_du_paris(driver,jeu,mise) == True:
                                    print('validation 097')
                                    validate_bet = 1
                                    jeu = jeu + 1
                                    perte = perte + mise
                                    wantwin = wantwin + increment
                                    print("prochain jeu : " + str(jeu))
                                    print("wantwin : " + str(wantwin))
                                    print("perte : " + str(perte))
                                    print("mise : " + str(mise))
                                    print("increment : " + str(increment))
                                else:
                                    print('err validation 49686')
                                    getjeu = Functions_1XBET.get_jeu_actuel(driver)
                                    tentative = tentative + 1
                                    if getjeu != jeu-1:
                                        validate_bet = 0
                                        #jeu = jeu + 1
                                        print("GAME PASS WITHOUT VALIDATE 2")
                                        gamestart = 0
                                        result = 1
                                        lose = 1
                                        findbtn = 1
                                        break
                        # RETOUR SUR LA SECTION TPS REGLEMENTAIRE
                        print("retour tps reg 3")
                        Functions_1XBET.retour_section_tps_reglementaire(driver)
                elif len(re.findall(str(newset) + ' Set', set_actuel)) > 0:##SI ON EST SUR LE PROCHAIN SET
                    findset = 1
                    findbtn = 1
                    validate = 1
                    set = str(newset) + " Set"
                    passageset = 1
                    result = 1
                    lose = ""
                    score_actuel = '0:0'
                    print('Passage prochain set')
                    Functions_1XBET.delete_bet(driver, error)
                    time.sleep(30)
                else:
                    print("ERROR : recup set " + set_actuel)
                    error = 1
            else:
                result = 0
                set_actuel = "nac"
                set_actuel = Functions_1XBET.get_set_actuel(driver, error,saved_set)
                saved_set = set_actuel
                if set_actuel == False:
                    error = 1
                else:
                    if saved_score != score_actuel:
                        print(score_actuel)
                        saved_score = score_actuel
                    numset = int(set.split(' ')[0])
                    newset = int(set.split(' ')[0]) + 1
                    if re.search('30', score_actuel):
                        timesleep = 1
                    else:
                        timesleep = 20
        if lose == 1 and error == 0:
            print('lose : ' + str(perte))
        elif lose == 0 and error == 0:
            win = win + 1
            try:
                btn_close = driver.find_elements(By.CLASS_NAME,
                'cpn-bet__remove')
            except:
                print('cpn-bet__remove not found')
            else:
                for close in btn_close:
                    try:
                        close.click()
                    except:
                        continue
            if rattrape_perte == 1:
                x = x + 1
                print("x : " + str(x))
                print("cote : "+str(cote))
                gain = (mise * cote) - perte - mise
                print("gain : "+str(gain))
                Functions_1XBET.maj_perte(script_num, gain, x)
            else:
                x=-1
            perte = 0
            mise = 0.2
            increment = 0.2
            wantwin = 0.2
            break
    if perte > 0:
        if perte >= 200:
            Functions_1XBET.update_lost(script_num, perte)
            perte = 0
            mise = 0.2
            increment = 0.2
            wantwin = 0.2
        else:
            if perte >10:
                ligue_name = 'wta'
            #if ligue_name == 'double' or ligue_name == 'couple':
                #ligue_name = 'wta'
            while perte > 5:
                #perte_partiel=5
                comp_list = ['wta', 'atp']
                ligue_name = random.choice(comp_list)
                Functions_gsheets.suivi_lost([5, 5, 2, ligue_name])
                perte = perte-5
            mise = (wantwin + perte) / (cote - 1)
            mise = round(mise, 2)
            Functions_gsheets.suivi_lost([perte, wantwin, mise,ligue_name])
            perte = 0
            mise = 0.2
            increment = 0.2
            wantwin = 0.2


    infos = [win, perte, wantwin, mise,x]
    print(newmatch)
    Functions_1XBET.update_match_done("del", newmatch,matchlist_file_name)
    Functions_1XBET.del_running(script_num,running_file_name)
    return infos
